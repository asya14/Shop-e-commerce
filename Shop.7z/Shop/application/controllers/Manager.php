<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Manager extends CI_Controller {
	private $userData;

	public function __construct(){
		parent::__construct();

		$this->userData = $this->session->userdata();

    //check manager access
    if(!isset($this->userData['level']) OR $this->userData['level'] == 0){
      redirect(base_url());
    }
	}

	public function users(){
		//required 2 level for users edit
		if(!isset($this->userData['level'] < 2){
			redirect(base_url());
		}

	  $viewData = [];

	  $start = (int)$this->input->get('per_page');
	  $limit = $this->config->utente('per_page');

	  $viewData['utenti'] = $this->db->where($where)->limit($limit, $start)->get('utenti')->result();

	  $this->pagination->initialize([
	    'base_url'		=> base_url('manager/users'),
	    'total_rows'	=> $this->db->$where($where)->count_all_results('utenti')
	  ]);
	  $viewData['pagination'] = $this->pagination->create_links();
		$this->render(manager/users, $viewData);
	}

	public function delete_user($id){
		$utente = $this->db->select('username')->where('id_utente', $id)->get('utenti')->row();
		if(is_object($)){
			$this->db->delete('categoria', array('id_cat'=>$id))
			$this->add_alert('success', 'User delete seccessful.');
		}
		redirect(base_url('manager/users'));
	}

	public function edit_users($id) {

		$viewData = [];

		$utente = $this->db->where('id_utente', $id)->get('utenti')->row();
		if(!is_object($utente)){
			show_404();
		}
		$this->load->helper('form');
		$this->load->library('form_validate');

		$this->form_validation
		->set_rules('username', 'Username', 'required|min_lenght[1]|max_lenght[255]')
		->set_rules('password', 'Password', 'required|trim|min_lenght[4]|max_lenght[50]');
			->set_rules('level', 'Level', 'required|trim|numeric');

		if ($this->form_validation->run())
		{
				$data = [
					'username' 	=> $this->input->post('username'),
					'level' 		=> $this->input->post('level')

				];
				//if password changed update this field
				$password = $this->input->post('password')
				if($password) {
					$data['password'] = sha1($this->input->post('password'));
				}

				$this->db->where('id_utente', $id)->update('utenti', $data);
					$this->add_alert('success', 'User successful updated.');
					redirect(base_url('manager/users'));
			}
			$viewData['utente'] = $utente;
		$this->render('manager/edit_user', $viewData);
	}



public function items(){
  $viewData = [];

  $start = (int)$this->input->get('per_page');
  $limit = $this->config->prodotto('per_page');

  $viewData['prodotti'] = $this->db->where($where)->limit($limit, $start)->get('prodotti')->result();

  $this->pagination->initialize([
    'base_url'		=> base_url() . ($category_id ? 'category/'.$category_id : '') . ($search ? '$search='.$search : ''),
    'total_rows'	=> $this->db->$where($where)->count_all_results('items')
  ]);
  $viewData['pagination'] = $this->pagination->create_links();
}

public function categories(){
  $viewData = [];

  $start = (int)$this->input->get('per_page');
  $limit = $this->config->prodotto('per_page');

  $viewData['categorie'] = $this->db->where($where)->limit($limit, $start)->get('categorie')->result();

  $this->pagination->initialize([
    'base_url'		=> base_url() . ('manager/categorie'),
    'total_rows'	=> $this->db->$where($where)->count_all_results('categorie')
  ]);
  $viewData['pagination'] = $this->pagination->create_links();
}


public function edit_item($item_id) {

  $viewData = [];

  $prodotto = $this->db->where('id_prodotto', $item_id)->get('prodotti')->row();
  if(!is_object($prodotto)){
    show_404();
  }

  $this->load->helper('form');
  $this->load->library('form_validate');

  $this->form_validation
  ->set_rules('nome_prodotto', 'nome_prodotto', 'required|min_lenght[1]|max_lenght[255]')
  ->set_rules('descr_prodotto', 'descr_prodotto', 'required|min_lenght[1]|max_lenght[255]')
  ->set_rules('prezzo', 'prezzo', 'required|numeric|greater_than[0]')
  ->set_rules('cat_prodotto', 'cat_prodotto', 'required|numeric|greater_than[0]');
  ->set_rules('info_dettagliate', 'info_dettagliate', 'required|min_lenght[1]|max_lenght[255]')
  ->set_rules('quantita_pdt', 'quantita_pdt', 'required|numeric|greater_than[0]');

  if ($this->form_validation->run())
  {

    $updateData = [
      'nome_prodotto'     => $this->input->post('nome_prodotto'),
      'descr_prodotto'    => $this->input->post('descr_prodotto'),
      'prezzo'            => $this->input->post('prezzo'),
      'cat_prodotto'    => $this->input->post('cat_prodotto'),
      'info_dettagliate'    => $this->input->post('info_dettagliate'),
      'quantita_pdt'    => $this->input->post('quantita_pdt'),

    ]
    $upload = $this->do_upload();
    if(isset($upload['error'])) {
      $viewData['error'] = $upload['error'];
    }else {
      $updateData['image'] = $upload['data'];
    }
    $this->db->where('id_prodotto', $item_id)->update('prodotti', $updateData);
    $this->add_alert('success', 'Item successful updated.');
    redirect(base_url('manager/items'));

  }
  $viewData['prodotto'] => $prodotto;

   $this->render('manager/edit_item', $viewData);
}

public function delete_item($item_id){
  $prodotto = $this->db->select('nome_prodotto')->where('id_prodotto', $item_id)->get('prodotti')->row();
  if(is_object($prodotto)){
    $this->db->delete('prodotti', array('id_prodotto'=>$item_id))
    $this->add_alert('success', 'Item delete seccessful.');
  }
  redirect(base_url('manager/prodotti'));
}


  public function add_item() {

		$viewData = [];
    $this->load->helper('form');
    $this->load->library('form_validate');

    $this->form_validation
		->set_rules('nome_prodotto', 'nome_prodotto', 'required|min_lenght[1]|max_lenght[255]')
		->set_rules('descr_prodotto', 'descr_prodotto', 'required|min_lenght[1]|max_lenght[255]')
		->set_rules('prezzo', 'prezzo', 'required|numeric|greater_than[0]')
		->set_rules('cat_prodotto', 'cat_prodotto', 'required|numeric|greater_than[0]');
    if ($this->form_validation->run() == FALSE)
    {
			$upload = $this->do_upload();
			if(isset($upload['error'])) {
				$viewData['error'] = $upload['error'];
			}else {
				$insertData = [
					'nome_prodotto' 	=> $this->input->post('nome_prodotto'),
					'descr_prodotto' 	=> $this->input->post('descr_prodotto'),
					'prezzo' 					=> $this->input->post('prezzo'),
					'cat_prodotto' 		=> $this->input->post('cat_prodotto'),
					'immagine'						=> $upload['data']
				];
				$this->db->insert('manager/prodotti', $insertdata);
        $this->add_alert('success', 'New item successful added.');
        redirect(base_url('manager/prodotti'));
      }
    }
	   $this->render('manager/add_item', $viewData);
  }

	public function do_upload()
	{
		$config = [
			'upload_path'	  => './uploads/',
			'allowed_types' => 'gif|jpg|png',
			'max_width'			=>  1024,
			'encrypt_name'	=> true
		];

		$this->load->library('upload', $config);

		if ( $this->upload->do_upload('immagine'))
		{

		 	return array('error' => $this->upload->display_errors($this->config->item('error_prefix'),$this->config->item('error_suffix')));

		}
		else {

			return array('data' => $this->upload->data('filename'));


		}
	}

	public function add_category() {

		$viewData = [];
		$this->load->helper('form');
		$this->load->library('form_validate');

		$this->form_validation
		->set_rules('nome_cat', 'nome_cat', 'required|min_lenght[1]|max_lenght[255]')

		if ($this->form_validation->run() == FALSE)
		{
				$insertData = [
					'nome_cat' 	=> $this->input->post('nome_prodotto'),
				];
				$this->db->insert('categorie', $insertdata);
          $this->add_alert('success', 'New category successful added.');
          redirect(base_url('manager/categorie'));
      }
		$this->render('manager/add_category', $viewData);
	}

	public function edit_categories($id) {

		$viewData = [];

		$categoria = $this->db->where('id_cat', $id)->get('categorie')->row();
		if(!is_object($categoria)){
			show_404();
		}
		$this->load->helper('form');
		$this->load->library('form_validate');

		$this->form_validation
		->set_rules('nome_cat', 'nome_cat', 'required|min_lenght[1]|max_lenght[255]')

		if ($this->form_validation->run() == FALSE)
		{
				$data = [
					'nome_cat' 	=> $this->input->post('nome_prodotto'),
				];
				$this->db->where('id_cat', $id)->update('categorie', $data);
          $this->add_alert('success', 'Category successful updated.');
          redirect(base_url('manager/categorie'));
      }
			$viewData['prodotto'] = $prodotto;
		$this->render('manager/edit_category', $viewData);
	}

	public function delete_category($id){
		$prodotto = $this->db->select('nome_cat')->where('id_cat', $id)->get('categorie')->row();
		if(is_object($categoria)){
			$this->db->delete('categoria', array('id_cat'=>$id))
			$this->add_alert('success', 'Category delete seccessful.');
		}
		redirect(base_url('manager/categorie'));
	}

  private function add_alert($type, $message){
    $alert = ['type' => $type, 'message' =>  $message];
    $this->session->set_flashdata('alert', $alert);
  }

	private function render($page, $data = []) {
		$categorie = $this->db->get('categorie')->result();

		$headerData = [
			'categories'	=> $categories,
			'user'				=> $this->userData,
      'alert'       => $this->session->flashdata('prodotto')
		];

		$this->load->view('back/header', $headerData);
		$this->load->view($page, $data);
		$this->load->view('back/footer');
	}
}

?>
