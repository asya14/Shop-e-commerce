<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	private $userData;

	public function __construct(){
		parent::__construct();

		$this->userData = $this->session->userdata();
	}

	public function index($category_id = 0)
	{

		$this->load->helper('url');
		$this->load->view('home');

		$viewData = [];
		$search = $this->input->get('search');
		$start = (int)$this->input->get('per_page');
		$limit = $this->config->item('per_page');
		$where =  [];

		if($search){
			$where[nome_prodotto LIKE] = '%. $search .%';
		}
		if($category_id){
			$where['id_cat'] = (int)$category_id;
		}

		$viewData['prodotti'] = $this->db->where($where)->limit($limit, $start)->get['prodotti']->result();
		$this->pagination->initialize([
			'base_url'		=> base_url('manager/prodotti'),
			'total_rows'	=> $this->db->count_all_results('prodotti')
		]);
		$viewData['pagination'] = $this->pagination->create_links();

		$this->render('home', $viewData);
	}

	public function add_cart($id_prodotto){
		if(!isset($this->userData['logged'])){
			$this->add_alert('warning', 'You must login firstly.');
			redirect(base_url('login'))
		} else {
				$prodotto = $this->db->where('id', id_prodotto)->get('prodotti')->row();
				if(!is_object($prodotto)){
					show_404();
				}
				$this->userData['cart'][] = $item_id;
				$this->session->set_userdata('cart', $this->userData['cart']);
				$this->add_alert('success', 'Product successful added to cart');
				redirect(base_url('cart'));
			}
		}

		public function cart(){
			if(!isset($this->userData['logged'])){
				redirect(base_url('login'));
			}

			$delete = $this->input->get('del');
			if($delete){
				unset($this->userData['cart'][$delete-1]);
					$this->session->set_userdata('cart', $this->userData['cart']);
				$this->add_alert('success', 'Successful deleted.');
				redirect(base_url('cart'));
			}

			$data = ['total' => 0];
			foreach ($this->userData['cart'] as $key=>$item_id) {
				$prodotto = $this->db->where('id_prodotto', $item_id)->get('items')->row();
				$data['prodotti'][$key] = $prodotto;
				$data['total'] += $prodotto->prezzo;
			}
			$this->render('cart', $data);
		}


	public function logout(){
		$this->session->unset_userdata([
			'logged','user_id', 'username'
		]);
		redirect(base_url());
	}

	public function login(){
		if(isset($this->userData['logged'])){
			redirect(base_url());
		}

		$viewData = [];
		$this->load->helper('form');
		$this->load->library('form_validate');

		$this->form_validation
							->set_rules('username', 'Username', 'required|min_lenght[1]|max_lenght[255]');
							->set_rules('password', 'password', 'required|trim');
							if ($this->form_validation->run()){
								$user = [
									'username' => $this->input->post('username'),
									'password' => sha1($this->input->post('password'))
								];
								$userData = $this->db
														->select('id', 'username', 'level')
														->where($user)->get('users')->row();
								if(is_object($userData)) {
									$newdata = [
										'logged'		=> true,
										'id_utente' 	=> $userData->id,
										'username'	=> $userData->username,
										'level'			=>$userData->level

									]
								}
								$newdata['cart'] = isset($this->userData['cart']) ? $this->userData['cart'] : [];
								$this->session->set_userdata($newdata);
								redirect(base_url());
							}else{
								$viewData['error'] = "Login or password incorrect.";
							}
		 $this->render('login', $viewData);
	}

	public function register() {
		if(isset($this->userData['logged'])){
			redirect(base_url());
		}

		$viewData = [];
		$this->load->helper('form');
		$this->load->library('form_validate');

		$this->form_validation
							->set_rules('username', 'Username', 'required|min_lenght[1]|max_lenght[255]');
							->set_rules('password', 'Password', 'required|trim');
							->set_rules('passconf', 'Password Confirm', 'required|trim|matches[password]');

							if ($this->form_validation->run()){
								$data = [
									'email' => $this->input->post('email'),
									'password' => sha1($this->input->post('password')),
								];
								$insert = $this->db->insert('utenti', $data);
								if($insert){
									$newdata = {
										'logged'	=> true,
										'level'		=> 0,
										'user_id'	=> $this->db->insert_id(),
										'username'		=> $data['username']
									}
									$newdata['cart'] = isset($this->userData['cart']) ? $this->userData['cart'] : [];
									$this->session->set_userdata($newdata);
									$viewData['success'] = true;
								}
							}

		 $this->render('register', $viewData);

	}

	private function add_alert($type, $message){
		$alert = ['type' => $type, 'message' =>  $message];
		$this->session->set_flashdata('alert', $alert);
	}


	private function render($page, $data = []) {
		$categorie = $this->db->get('categorie')->result();

		$headerData = [
			'categories'	=> $categories,
			'user'				=> $this->userData,
			'alert'				=> $this->session->flashdata('alert')
		];

		$this->load->view('back/header', $headerData);
		$this->load->view($page, $data);
		$this->load->view('back/footer');
	}




}

?>
