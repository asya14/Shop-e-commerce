<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-12">
      <h1>Edit item</h1>

      <?=isset($error) ? $error : ''?>
      <?=validation_errors()?>
      <?=form_open_multipart(base_url('manager/edit_items' . $prodotto->id_prodotto))?>
        <div class="form-group">
          <label for="nome_prodotto">Nome prodotto</label>
          <input type="text" class="form-control" id="nome_prodotto" name="nome_prodotto" value="<?=set_value('nome_prodotto')?>">
        </div>
        <div class="form-group">
          <label for="descr_prodotto">Descrizione</label>
          <input type="text" class="form-control" id="descr_prodotto"
          name="descr_prodotto" value="<?=set_value('descr_prodotto', $prodotto->desc_prodotto)?>">
        </div>
        <div class="form-group">
          <label for="prezzo">Prezzo</label>
          <input type="number" class="form-control" min="0" step="0.01" id="prezzo"
          name="prezzo" value="<?=set_value('prezzo', $prodotto->prezzo)?>">
        </div>
        <div class="form-group">
          <label for="cat_prodotto">Categoria</label>
          <input type="number" class="form-control" id="cat_prodotto"
          name="cat_prodotto" value="<?=set_value('cat_prodotto', $prodotto->cat_prodotto)?>">
        </div>
        <div class="form-group">
          <label for="image">Immagine</label>
          <input type="file" class="form-control-file" name="immagine" id="immagine">
        </div>
        <div class="row">
          <div class="col-12">
            <img src="<?=base_url('uploads/' . $prodotto->image)?>" class="img-thumbnail"/>
        </div>
        <div class="form-group">
          <label for="info_dettagliate">Info dettagliate</label>
          <input type="number" class="form-control" id="info_dettagliate" name="info_dettagliate" value="<?=set_value('info_dettagliate', $prodotto->info_dettagliate)?>">
        </div>
        <div class="form-group">
          <label for="quantita_pdt">Quantità</label>
          <input type="number" class="form-control" id="quantita_pdt" name="quantità_pdt" value="<?=set_value('quantita_pdt', $prodotto->quantita_pdt)?>">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
      <?=form_close()?>
    </div>
  </div>
  </div>

</body>
</html>
