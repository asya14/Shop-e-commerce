<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-12">
      <h1>Edit category</h1>
      <?=isset($error) ? $error : ''?>
      <?=validation_errors()?>
      <?=form_open(base_url('manager/edit_category/' . $categoria->id))?>
        <div class="form-group">
          <label for="nome_prodotto">Nome categoria</label>
          <input type="text" class="form-control" id="nome_cat"
          name="nome_cat" value="<?=set_value('nome_cat', $categoria->nome_cat)?>">
        </div>
        <div class="form-group">
          <label for="nome_prodotto">Didascalia</label>
          <input type="text" class="form-control" id="didascalia"
          name="didascalia" value="<?=set_value('didascalia', $categoria->didascalia)?>">
        </div>
        <button type="submit" class="btn btn-primary">Save</button>
      <?=form_close()?>
    </div>
  </div>
  </div>

</body>
</html>
