<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h1>Categorie<a class="btn btn-success" href="<?=base_url('manager/add_category')?>">New category</h1>
      </div>
    </div>
    <div class="row">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Didascalia</th>
          </tr>
        </thead>
        <tbody>
          <?foreach($categorie as $categoria):?>
          <tr>
            <th scope="row"><?=$categoria->id_cat?></th>
            <td><?=$categoria->nome_cat?></td>
            <td><?=$categoria->didascalia?></td>
            <td>
              <a class="btn btn-delete" href="<?=base_url('manager/delete_category/' . $categoria->id_categoria)?>">Delete</a>
              <span class="oi oi-trash"></span>
            </a>
              <a class="btn btn-primary" href="<?=base_url('manager/edit_category/' . $categoria->id_categoria)?>">Edit</a>
              <span class="oi oi-pencil"></span>
            </a>
            </td>
          </tr>
          <?endforeach;?>
        </tbody>
      </table>

  </div>
  <div class="row">
    <div class="col-12 m-auto">
    <?=$pagination?>
  </div>
  </div>
  </div>

</body>
</html>
