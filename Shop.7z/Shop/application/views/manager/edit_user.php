<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-12">
      <h1>Edit user</h1>

      <?=validation_errors()?>
      <?=form_open(base_url('manager/edit_user' . $utente->id_utente))?>
        <div class="form-group">
          <label for="username">Username</label>
          <input type="text" class="form-control" id="username" name="username" value="<?=set_value('username', $user->username)?>">
        </div>
        <div class="form-group">
          <label for="username">Password</label>
          <input type="text" class="form-control" id="password" name="password" value="<?=set_value('password')?>">
        </div>
        <div class="form-group">
          <label for="username">Level</label>
          <input type="number" min="0" step="1" class="form-control" id="level" name="level" value="<?=set_value('level', $user->level)?>">
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
      <?=form_close()?>
    </div>
  </div>
  </div>

</body>
</html>
