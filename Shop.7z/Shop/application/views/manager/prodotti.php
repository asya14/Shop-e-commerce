<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h1>Prodotti<a class="btn btn-success" href="<?=base_url('manager/add_item')?>">New item</h1>
      </div>
    </div>
    <div class="row">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Nome</th>
            <th scope="col">Descrizione</th>
            <th scope="col">Prezzo</th>
            <th scope="col">Categoria</th>
            <th scope="col">Immagine</th>
            <th scope="col">Info dettagliate</th>
            <th scope="col">Quantità</th>
          </tr>
        </thead>
        <tbody>
          <?foreach($prodotti as $prodotto):?>
          <tr>
            <th scope="row"><?=$prodotto->id_prodotto?></th>
            <td><?=$prodotto->nome_prodotto?></td>
            <td><?=$prodotto->descr_prodotto?></td>
            <td><?=$prodotto->prezzo?></td>
            <td><?=$prodotto->cat_prodotto?></td>
            <td><?=$prodotto->immagine?></td>
            <td><?=$prodotto->info_dettagliate?></td>
            <td><?=$prodotto->quantita_pdt?></td>
            <td>
              <a class="btn btn-delete" href="<?=base_url('manager/delete_item/' . $prodotto->id_prodotto)?>">Delete</a>
              <span class="oi oi-trash"></span>
            </a>
              <a class="btn btn-primary" href="<?=base_url('manager/edit_item/' . $prodotto->id_prodotto)?>">Edit</a>
              <span class="oi oi-pencil"></span>
            </a>
            </td>
          </tr>
          <?endforeach;?>
        </tbody>
      </table>

  </div>
  <div class="row">
    <div class="col-12 m-auto">
    <?=$pagination?>
  </div>
  </div>
  </div>

</body>
</html>
