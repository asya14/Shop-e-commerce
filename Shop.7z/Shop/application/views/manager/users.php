<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h1>Users</h1>
      </div>
    </div>
    <div class="row">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Username</th>
            <th scope="col">Password</th>
          </tr>
        </thead>
        <tbody>
          <?foreach($utenti as $utente):?>
          <tr>
            <th scope="row"><?=$utente->id_utente?></th>
            <td><?=$utente->username?></td>
            <td><?=$utente->password?></td>
            <td>
              <a class="btn btn-delete" href="<?=base_url('manager/delete_user/' . $prodotto->id_prodotto)?>">Delete</a>
              <span class="oi oi-trash"></span>
            </a>
              <a class="btn btn-primary" href="<?=base_url('manager/edit_user/' . $prodotto->id_prodotto)?>">Edit</a>
              <span class="oi oi-pencil"></span>
            </a>
            </td>
          </tr>
          <?endforeach;?>
        </tbody>
      </table>

  </div>
  <div class="row">
    <div class="col-12 m-auto">
    <?=$pagination?>
  </div>
  </div>
  </div>

</body>
</html>
