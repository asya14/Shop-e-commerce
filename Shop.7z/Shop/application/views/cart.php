<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php  $this->load->view('back/header.php'); ?>
<div class="container">
  <div class="row">
    <div class="col-12">
      <h1>Shopping cart</h1>
    </div>
    <div class='col-12'>
      <?if(!isset($prodotti) || count($prodotti) == 0):?>
        <div class="alert alert-warning">Your cart is empty</div>
      <?else:?>
      <?foreach ($prodotti as $id => $prodotto) :?>
        <div class="row">
          <div class="col-4">
            <img src="<?=base_url('uploads/' . $item->image)?>" alt="" class="img-thumbnail">
          </div>
        <div class="col--6"><h3><?=$prodotto->nome_prodotto?></h3></div>
        <div class="col--6"><h3><?=$prodotto->prezzo?></h3></div>
        <div class="col-1">
          <a class="btn btn-danger delete" href="<?=base_url() . 'cart?del=' . ($id+1)?>"></a>
          <span class="oi oi-trash"></span>
        </div>
      <?endforeach;endif;?>
      <hr>
      <div class="row">
        <div class="col-6"><h2>Total:</h2></div>
        <div class="col-4"><h2><?=total?>EUR</h2></div>
      </div>
      <div class="row">
        <div class="col-4 offset-md-8">
          <a class="btn btn-success btn-block" href="">Checkout</a>
        </div>
      <?div>
      <?endif;?>
    </div>
  </div>
</div>
