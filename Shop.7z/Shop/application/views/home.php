<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<?php  $this->load->view('back/header.php'); ?>
<div class="container">
  <div class="row">
    <div class='col-12'>
      <h1>Prodotti</h1>
    </div>
  </div>
  <div class="row">
    <?if(count($prodotti)==0);?>
      <div class="col-6">
        <div class="alert alert-danger">Product not found</div>
      </div>
    <?endif;?>
    <?php foreach($prodotti as $prodotto): ?>
    <div class="card">
      <img src="<?=base_url('uploads/'.$prodotto->immagine)?>"
      class="card-img-top" alt="<?=$prodotto->nome_prodotto?>">
      <div class="card-body">
        <h5 class="card-title"><?=$prodotto->nome_prodotto?></h5>
        <p class="card-title"><?=item->price?>></p>
        <a href="<?=base_url('back/' . $prodotto->id_prodotto)?>" class="btn btn_primary">Add to bag</a>
    </div>
  </div>
      </div>
      <?endforeach;?>
  </div>
  <div class="row">
    <div class="col-12 m-auto">
    <?=$pagination?>
  </div>
  </div>
</div>
