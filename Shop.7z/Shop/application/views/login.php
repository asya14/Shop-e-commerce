<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
  <div class="container">
    <div class="row">
      <div class="col-6 offset-md-3 text-center">
      <h1 class="mb-3">Login</h1>
      <?=if(isset($error)):?>
        <div class="alert alert-danger"><?=$error?></div>
      <?endif;?>

      <?=validation_errors()?>
      <?=form_open(base_url('home/login'))?>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Username" required name="username" value="<?=set_value('username')?>">
        </div>
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Password" required name="password" value="<?=set_value('password')?>">
        </div>
        <button type="submit" class="btn btn-block btn-primary">Enter</button>
      <?=form_close()?>
      <div class="row">
        <div class="col-12">
          <a class="btn btn-info at-4" href="<?=base_url('home/register')?>">Register</a>
        </div>
      </div>

  </div>
  </div>

</body>
</html>
