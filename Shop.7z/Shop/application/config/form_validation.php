<?php
$config['error_prefix'] = '<div class="alert alert-danger" role="alert">';
$config['error_suffix'] = '<div>';

?>
