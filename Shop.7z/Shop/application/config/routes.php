<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['login'] = 'home/login';
$route['register'] = 'home/register';
$route['cart'] = 'home/cart';
$route['checkout'] = 'home/checkout';

$route['categoria/(:num)'] = 'home/index/$1';
$route['back/(:num)'] = 'home/add_card/$1';
