$(document).ready(function(){

  //check for have link with delete class
  if($("a.delete").lenght){
    $("a.delete").click(function(e)){
      e.preventDefault();
      if(cconfirm("Are you sure?")){
        window.location.href = $(this).attr("href");
      }
    }
  }
});
